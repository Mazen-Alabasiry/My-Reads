import React from 'react'
import './PageLoad.css'
export default function PageLodaing() {

    return (
        <div>
            {/* <h1 style={{ color: '#4caf50', textAlign: 'center', position: 'relative', top: '180px' }}>page loading...</h1> */}
            <div className='relaod-circle'></div>
            
        </div>
    )
}
